## Getting Started

Welcome to VectorBT® PRO!

Visit [the private website](https://github.com/polakowo/vectorbt.pro/blob/pvt-links/README.md) and follow the guide.

Also make sure to join our private [Discord server](https://discord.gg/eQ9sVr5vb9)!

## Terms

> __It is illegal to vend, publish, distribute, or commercialize the vectorbtpro source code without
> separate permission. Violating the licensing terms will result in a ban and potential legal action.__
> 
> Any licensed user, developer, team, or company that has obtained paid access to the vectorbtpro
> repository from us may use vectorbtpro as a dependency, subject to the terms and limitations of the
> paid subscription plans. Licensees may use, copy, and modify vectorbtpro as long as they do not vend,
> publish, distribute, or commercialize the source code of vectorbtpro. You may specify vectorbtpro as
> a dependency for your software, provided you do not include a copy of the vectorbtpro source code in
> your software. If you are a software developer, you should specify vectorbtpro as a requirement. The
> end user of your software is responsible for obtaining their own individual license. The best practice
> is to make this clear in your documentation or on your website.

Copyright (c) 2021-2025 Oleg Polakow. All rights reserved.
