"""
IO utilities for candle data (CSV/Parquet/DB), validation and causal resampling.

Functions:
- read_file(path) -> pd.DataFrame
- validate_candles_df(df, symbol=None, timeframe=None) -> (df_clean, report)
- resample_candles(df, src_tf, tgt_tf) -> df_resampled
- ensure_candles_table(engine) -> sqlalchemy.Table
- upsert_candles(engine, df, symbol, timeframe, resampled=False) -> qa_report
- get_last_ts_for_symbol_tf(engine, symbol, timeframe) -> Optional[int]
- backfill_from_provider(engine, provider_client, symbol, timeframe, start_ts_ms, end_ts_ms)
"""

from __future__ import annotations

import math
from datetime import datetime, timezone
from typing import Dict, Optional, Tuple

import pandas as pd
import numpy as np
from loguru import logger
from sqlalchemy import (
    MetaData,
    Table,
    Column,
    Integer,
    String,
    Float,
    Boolean,
    create_engine,
    select,
    insert,
    text,
)
from sqlalchemy.engine import Engine
from sqlalchemy.exc import SQLAlchemyError

from ..utils.config import get_config

# Column names expected
COLUMNS = ["ts_utc", "open", "high", "low", "close", "volume"]

# Map timeframe labels to pandas offset aliases (used for resampling)
# Use 'min' aliases instead of deprecated 'T'
TF_TO_PANDAS = {
    "1m": "1min",
    "2m": "2min",
    "3m": "3min",
    "4m": "4min",
    "5m": "5min",
    "15m": "15min",
    "30m": "30min",
    "60m": "60min",
    "1h": "60min",
    "1d": "1D",
    "1D": "1D",
    "2h": "120min",
    "4h": "240min",
}


def read_file(path: str) -> pd.DataFrame:
    """
    Read CSV or Parquet into a DataFrame. Normalize column names to expected ones.
    Expects ts column in milliseconds UTC or as ISO datetimes (will be converted).
    """
    p = pd.Path(path) if hasattr(pd, "Path") else None
    path_lower = str(path).lower()
    if path_lower.endswith(".parquet") or path_lower.endswith(".pq"):
        df = pd.read_parquet(path)
    else:
        df = pd.read_csv(path)
    # Normalize column names
    df_columns = {c: c.strip() for c in df.columns}
    df.rename(columns=df_columns, inplace=True)
    # Ensure ts_utc exists or infer from common names
    if "ts_utc" not in df.columns:
        for cand in ["ts", "timestamp", "time", "date"]:
            if cand in df.columns:
                df = df.rename(columns={cand: "ts_utc"})
                break
    return df


def _to_ms_int_series(series: pd.Series) -> pd.Series:
    """
    Convert a timestamp series to integer milliseconds (UTC).
    Accepts int(ms), int(s), or pandas datetime.
    """
    if pd.api.types.is_integer_dtype(series):
        # Heuristic: if values look like seconds (<= 1e10) convert to ms
        if series.max() < 10_000_000_000:
            return (series.astype("int64") * 1000).astype("int64")
        return series.astype("int64")
    # Try datetime conversion
    ts = pd.to_datetime(series, utc=True, errors="coerce")
    return (ts.view("int64") // 1_000_000).astype("Int64")


def validate_candles_df(
    df: pd.DataFrame, symbol: Optional[str] = None, timeframe: Optional[str] = None
) -> Tuple[pd.DataFrame, Dict]:
    """
    Validate and sanitize a candles DataFrame.

    Returns (df_clean, report) where report contains:
    - n_rows
    - n_dups
    - n_out_of_order
    - n_invalid_price_relation
    - gaps: list of (prev_ts, next_ts, delta_ms)
    """
    report: Dict = {}
    df2 = df.copy()

    # Normalize columns
    for col in ["open", "high", "low", "close"]:
        if col not in df2.columns:
            raise ValueError(f"Missing required column: {col}")

    # ts_utc normalization
    if "ts_utc" not in df2.columns:
        raise ValueError("ts_utc column is required")
    df2["ts_utc"] = _to_ms_int_series(df2["ts_utc"])
    # Drop rows with NaT/NA ts
    before = len(df2)
    df2 = df2[df2["ts_utc"].notna()]
    after = len(df2)
    report["rows_dropped_invalid_ts"] = before - after

    # Sort by ts_utc
    df2 = df2.sort_values("ts_utc").reset_index(drop=True)

    # Check duplicates
    if symbol is not None and timeframe is not None:
        # duplicates identified by triple, but at this stage we only have ts
        dup_mask = df2.duplicated(subset=["ts_utc"], keep=False)
    else:
        dup_mask = df2.duplicated(subset=["ts_utc"], keep=False)
    n_dups = int(dup_mask.sum())
    report["n_dups"] = n_dups
    if n_dups > 0:
        # Keep first occurrence
        df2 = df2[~df2.duplicated(subset=["ts_utc"], keep="first")].reset_index(drop=True)

    # Price relationships: high >= max(open, close); low <= min(open, close); low <= high
    cond_high = df2["high"] >= df2[["open", "close"]].max(axis=1)
    cond_low = df2["low"] <= df2[["open", "close"]].min(axis=1)
    cond_lr = df2["low"] <= df2["high"]
    valid_prices = cond_high & cond_low & cond_lr
    n_invalid_price_relation = int((~valid_prices).sum())
    report["n_invalid_price_relation"] = n_invalid_price_relation
    if n_invalid_price_relation > 0:
        # Drop invalid rows (could alternatively attempt to fix)
        df2 = df2[valid_prices].reset_index(drop=True)

    # Gaps detection: if timeframe provided, compute expected delta
    gaps = []
    report["n_gaps_flagged"] = 0
    if timeframe and timeframe in TF_TO_PANDAS:
        # convert pandas offset to minutes
        if timeframe.endswith("m") or timeframe.endswith("T"):
            # e.g., '5m' -> 5
            try:
                expected_delta_ms = int(pd.to_timedelta(TF_TO_PANDAS[timeframe]).total_seconds() * 1000)
            except Exception:
                expected_delta_ms = None
        else:
            try:
                expected_delta_ms = int(pd.to_timedelta(TF_TO_PANDAS[timeframe]).total_seconds() * 1000)
            except Exception:
                expected_delta_ms = None
    else:
        expected_delta_ms = None

    if expected_delta_ms:
        ts = df2["ts_utc"].astype("int64").to_numpy()
        if len(ts) >= 2:
            deltas = ts[1:] - ts[:-1]
            idx = np.where(deltas > expected_delta_ms)[0]
            for i in idx:
                gaps.append({"prev_ts": int(ts[i]), "next_ts": int(ts[i + 1]), "delta_ms": int(deltas[i])})
        report["n_gaps_flagged"] = len(gaps)
        report["gaps"] = gaps

    report["n_rows"] = len(df2)
    report["symbol"] = symbol
    report["timeframe"] = timeframe
    return df2, report


def resample_candles(df: pd.DataFrame, src_tf: str, tgt_tf: str) -> pd.DataFrame:
    """
    Causal resampling from src_tf to tgt_tf.
    - open = first open in period
    - close = last close in period
    - high = max(high)
    - low = min(low)
    - volume = sum(volume)
    Input df must contain ts_utc in ms and OHLCV columns.
    """
    if src_tf == tgt_tf:
        return df.copy()

    if tgt_tf not in TF_TO_PANDAS:
        raise ValueError(f"Target timeframe {tgt_tf} not supported for resampling.")

    if "ts_utc" not in df.columns:
        raise ValueError("ts_utc column required for resampling")

    # Convert to datetime index in UTC
    tmp = df.copy()
    tmp["ts_dt"] = pd.to_datetime(tmp["ts_utc"].astype("int64"), unit="ms", utc=True)
    tmp = tmp.set_index("ts_dt")

    rule = TF_TO_PANDAS[tgt_tf]
    agg = {
        "open": "first",
        "high": "max",
        "low": "min",
        "close": "last",
    }
    if "volume" in tmp.columns:
        agg["volume"] = "sum"
    res = tmp.resample(rule, origin="start_day", label="right", closed="right").agg(agg)

    # Drop periods without data (NaN open/close)
    res = res.dropna(subset=["open", "close"]).reset_index()
    # ts_utc should be the timestamp of the period end (right label)
    res["ts_utc"] = (res["ts_dt"].view("int64") // 1_000_000).astype("int64")
    res = res[["ts_utc", "open", "high", "low", "close"] + (["volume"] if "volume" in res.columns else [])]
    return res


def _get_engine_from_url(database_url: Optional[str] = None) -> Engine:
    cfg = get_config()
    url = database_url or getattr(cfg.db, "database_url", None)
    if not url:
        raise ValueError("Database URL is not configured")
    # echo disabled by default; caller can enable
    engine = create_engine(url, future=True)
    return engine


def ensure_candles_table(engine: Engine) -> Table:
    """
    Ensure the candles table exists with the required schema.
    Primary key enforced on (symbol, timeframe, ts_utc) via unique index.
    """
    metadata = MetaData()
    candles = Table(
        "market_data_candles",
        metadata,
        Column("id", Integer, primary_key=True, autoincrement=True),
        Column("symbol", String(64), nullable=False, index=True),
        Column("timeframe", String(16), nullable=False, index=True),
        Column("ts_utc", Integer, nullable=False, index=True),
        Column("open", Float, nullable=False),
        Column("high", Float, nullable=False),
        Column("low", Float, nullable=False),
        Column("close", Float, nullable=False),
        Column("volume", Float, nullable=True),
        Column("resampled", Boolean, default=False),
    )
    metadata.create_all(engine)
    # Create a unique composite index if not present (SQLite supports)
    try:
        with engine.begin() as conn:
            conn.exec_driver_sql(
                "CREATE UNIQUE INDEX IF NOT EXISTS ux_market_symbol_tf_ts ON market_data_candles(symbol, timeframe, ts_utc);"
            )
    except Exception:
        logger.debug("Could not create unique index (may already exist or unsupported).")
    return candles


def upsert_candles(engine: Engine, df: pd.DataFrame, symbol: str, timeframe: str, resampled: bool = False) -> Dict:
    """
    Upsert candles into the DB. Uses SQLite 'INSERT OR REPLACE' semantics where available.
    Returns a QA report including rows_inserted, rows_upserted, n_dups_resolved.
    """
    if df.empty:
        return {"rows_inserted": 0, "rows_upserted": 0, "note": "empty_dataframe"}

    # Validate
    dfv, vreport = validate_candles_df(df, symbol=symbol, timeframe=timeframe)
    # Sanitize validation report for logging: suppress potentially large 'gaps' details
    try:
        vreport_sanitized = dict(vreport) if isinstance(vreport, dict) else {"note": "invalid_vreport_type"}
        if isinstance(vreport_sanitized, dict) and "gaps" in vreport_sanitized:
            # remove full gaps payload and replace with a brief marker containing the count
            n_gaps = vreport_sanitized.get("n_gaps_flagged", "?")
            vreport_sanitized.pop("gaps", None)
            vreport_sanitized["gaps"] = f"<suppressed {n_gaps} items>"
    except Exception:
        vreport_sanitized = {"note": "failed_to_sanitize_vreport"}
    # Validation log removed to reduce noise

    # Prepare engine & table
    tbl = ensure_candles_table(engine)

    rows = []
    for _, r in dfv.iterrows():
        # normalize volume: handle None or NaN safely, leave as None if absent/invalid
        vol_raw = None
        if "volume" in r:
            try:
                vol_raw = r.get("volume", None)
            except Exception:
                vol_raw = None
        vol = None
        try:
            # treat numpy nan as missing
            if vol_raw is not None and not (isinstance(vol_raw, float) and np.isnan(vol_raw)):
                vol = float(vol_raw)
            else:
                vol = None
        except Exception:
            vol = None

        row = {
            "symbol": symbol,
            "timeframe": timeframe,
            "ts_utc": int(r["ts_utc"]),
            "open": float(r["open"]),
            "high": float(r["high"]),
            "low": float(r["low"]),
            "close": float(r["close"]),
            "volume": vol,
            "resampled": bool(resampled),
        }
        rows.append(row)

    inserted = 0
    upserted = 0
    try:
        with engine.begin() as conn:
            # For SQLite, use OR REPLACE with prefix
            dialect_name = conn.dialect.name.lower()
            if dialect_name == "sqlite":
                stmt = insert(tbl).prefix_with("OR REPLACE")
                conn.execute(stmt, rows)
                inserted = len(rows)
                upserted = len(rows)
            else:
                # Generic upsert: try execute insert and ignore conflicts if supported
                stmt = insert(tbl)
                try:
                    conn.execute(stmt, rows)
                    inserted = len(rows)
                except SQLAlchemyError:
                    # Fallback: insert one-by-one with replacement
                    for r in rows:
                        stmt = insert(tbl).values(**r)
                        conn.execute(stmt)
                    inserted = len(rows)
                    upserted = len(rows)
    except Exception as exc:
        logger.exception("Failed to upsert candles: {}", exc)
        raise

    report = {
        "rows_inserted": inserted,
        "rows_upserted": upserted,
        "validation": vreport,
    }
    # Upsert info log removed to reduce log noise
    return report


def get_last_ts_for_symbol_tf(engine: Engine, symbol: str, timeframe: str) -> Optional[int]:
    """
    Return last ts_utc for given symbol and timeframe, or None if no rows.
    """
    tbl = ensure_candles_table(engine)
    with engine.connect() as conn:
        stmt = select(tbl.c.ts_utc).where(tbl.c.symbol == symbol).where(tbl.c.timeframe == timeframe).order_by(
            tbl.c.ts_utc.desc()
        ).limit(1)
        r = conn.execute(stmt).first()
        if r:
            return int(r[0])
        return None


def backfill_from_provider(
    engine: Engine,
    provider_client,
    symbol: str,
    timeframe: str,
    start_ts_ms: int,
    end_ts_ms: int,
    resampled: bool = False,
    db_writer=None,
) -> Dict:
    """
    Tick-first backfill workflow:
      1) Compute candidate subranges between start_ts_ms and end_ts_ms excluding Fri22:00UTC -> Sun22:00UTC windows.
      2) For each subrange, detect minute buckets (ts_utc // 60000) missing in market_data_ticks (i.e. no tick in that minute).
      3) For contiguous missing minute ranges, fetch ticks from provider (provider_client.get_historical_ticks if available,
         otherwise provider_client.get_historical with 'tick' or fallback), and persist ticks into market_data_ticks.
      4) After ticks saved, aggregate ticks into candles for the given timeframe and upsert into market_data_candles.
    Returns a combined report with counts.
    """
    cfg = get_config()
    logger.info("Tick-first backfill %s %s [%s,%s)", symbol, timeframe, start_ts_ms, end_ts_ms)

    import datetime
    from sqlalchemy import text as _text

    def week_exclusion_segments(a_ms: int, b_ms: int) -> List[Dict[str, int]]:
        """
        Yield subranges within [a_ms,b_ms) that exclude Fri22->Sun22 windows.
        Return list of {'start':..., 'end':...}.
        """
        out = []
        if a_ms >= b_ms:
            return out
        a_dt = datetime.datetime.utcfromtimestamp(a_ms / 1000.0)
        b_dt = datetime.datetime.utcfromtimestamp(b_ms / 1000.0)
        cur = a_dt
        # iterate week by week
        while cur < b_dt:
            # find next Friday 22:00 after or at cur
            days_to_friday = (4 - cur.weekday()) % 7
            friday = (cur + datetime.timedelta(days=days_to_friday)).replace(hour=22, minute=0, second=0, microsecond=0)
            if friday < cur:
                friday += datetime.timedelta(weeks=1)
            seg_end = min(friday, b_dt)
            if cur < seg_end:
                out.append({"start": int(cur.timestamp() * 1000), "end": int(seg_end.timestamp() * 1000)})
            # skip weekend window
            weekend_end = friday + datetime.timedelta(days=2)  # sunday 22:00
            cur = weekend_end
            if cur < a_dt:
                cur = a_dt
        return out

    def existing_tick_minutes(engine, s_ms: int, e_ms: int) -> set:
        """
        Return set of minute buckets (int) for which ticks exist in market_data_ticks for symbol/timeframe in [s_ms,e_ms).
        Minute bucket = ts_utc // 60000
        """
        try:
            q = _text("SELECT DISTINCT (ts_utc/60000) AS m FROM market_data_ticks WHERE symbol = :s AND timeframe = :tf AND ts_utc >= :a AND ts_utc < :b")
            with engine.connect() as conn:
                rows = conn.execute(q, {"s": symbol, "tf": timeframe, "a": int(s_ms), "b": int(e_ms)}).fetchall()
                return set(int(r[0]) for r in rows if r[0] is not None)
        except Exception as e:
            logger.exception("Failed to query existing tick minutes: {}", e)
            return set()

    def missing_minute_ranges(a_ms: int, b_ms: int, existing_minutes: set) -> List[Dict[str, int]]:
        """
        Compute contiguous missing minute ranges (in ms) within [a_ms,b_ms) given existing minute buckets.
        Return list of {'start': ms_start, 'end': ms_end}.
        """
        start_min = int(a_ms // 60000)
        end_min = int((b_ms - 1) // 60000) + 1
        missing = []
        cur_missing_start = None
        for m in range(start_min, end_min):
            if m not in existing_minutes:
                if cur_missing_start is None:
                    cur_missing_start = m
            else:
                if cur_missing_start is not None:
                    # close range [cur_missing_start, m)
                    missing.append({"start": cur_missing_start * 60000, "end": m * 60000})
                    cur_missing_start = None
        if cur_missing_start is not None:
            missing.append({"start": cur_missing_start * 60000, "end": end_min * 60000})
        return missing

    def fetch_and_persist_ticks_for_range(engine, provider, a_ms, b_ms):
        """
        Fetch ticks from provider for [a_ms,b_ms) and persist via DBService.write_tick.
        If provider returns candles only, synthesize one tick per candle (ts_utc -> price=close)
        so minute-buckets are populated. Returns counts and diagnostics.
        """
        try:
            # try tick-specific endpoint first
            if hasattr(provider, "get_historical_ticks"):
                logger.info("Calling provider.get_historical_ticks for [%s,%s)", a_ms, b_ms)
                df_src = provider.get_historical_ticks(symbol=symbol, timeframe=timeframe, start_ts_ms=a_ms, end_ts_ms=b_ms)
            else:
                # fallback: try to request tick-like data; some providers return candles only
                logger.info("Calling provider.get_historical (tick fallback) for [%s,%s)", a_ms, b_ms)
                try:
                    df_src = provider.get_historical(symbol=symbol, timeframe="tick", start_ts_ms=a_ms, end_ts_ms=b_ms)
                except Exception:
                    # fallback to general historical (may return candles)
                    df_src = provider.get_historical(symbol=symbol, timeframe=timeframe, start_ts_ms=a_ms, end_ts_ms=b_ms)
        except Exception as e:
            logger.exception("Provider fetch failed for %s %s [%s,%s): {}", symbol, timeframe, a_ms, b_ms, e)
            return {"provider_rows": 0, "inserted": 0, "failed": 0, "error": str(e)}

        if df_src is None:
            logger.info("Provider returned None for [%s,%s)", a_ms, b_ms)
            return {"provider_rows": 0, "inserted": 0, "failed": 0}

        # normalize to DataFrame
        if not isinstance(df_src, pd.DataFrame):
            try:
                df_src = pd.DataFrame(df_src)
            except Exception:
                logger.warning("Provider returned non-tabular data for [%s,%s); skipping", a_ms, b_ms)
                return {"provider_rows": 0, "inserted": 0, "failed": 0}

        logger.info("Provider returned %d rows for [%s,%s); columns=%s", len(df_src), a_ms, b_ms, list(df_src.columns))

        # Determine if these are raw ticks (has 'price' or 'bid'/'ask') or candles (has 'open'/'close')
        is_tick_like = any(c in df_src.columns for c in ("price", "bid", "ask"))
        is_candle_like = all(c in df_src.columns for c in ("open", "high", "low", "close")) or ("close" in df_src.columns and "ts_utc" in df_src.columns)

        from ..services.db_service import DBService
        dbs = DBService(engine=engine)
        inserted = 0
        failed = 0
        sample_log_limit = 5
        sample_logged = 0

        if is_tick_like:
            logger.info("Persisting provider ticks for [%s,%s): rows=%d", a_ms, b_ms, len(df_src))
            for idx, r in df_src.iterrows():
                try:
                    ts_val = int(r.get("ts_utc"))
                except Exception:
                    failed += 1
                    continue
                payload_tick = {
                    "symbol": symbol,
                    "timeframe": timeframe,
                    "ts_utc": ts_val,
                    "price": r.get("price", None),
                    "bid": r.get("bid", None),
                    "ask": r.get("ask", None),
                    "volume": r.get("volume", None),
                    "ts_created_ms": int(time.time() * 1000),
                }
                try:
                    ok = dbs.write_tick(payload_tick)
                    if ok:
                        inserted += 1
                    else:
                        failed += 1
                    if sample_logged < sample_log_limit:
                        logger.debug("write_tick attempt ts=%s ok=%s price=%s", ts_val, ok, payload_tick.get("price"))
                        sample_logged += 1
                except Exception as e:
                    failed += 1
                    logger.exception("write_tick exception for ts=%s: {}", ts_val, e)
            logger.info("fetch_and_persist_ticks: provider_rows=%d inserted=%d failed=%d", len(df_src), inserted, failed)
            return {"provider_rows": len(df_src), "inserted": inserted, "failed": failed}

        if is_candle_like:
            # synthesize ticks from candles: use ts_utc and close as a representative tick
            logger.info("Provider returned candles for [%s,%s); synthesizing ticks (price=close) rows=%d", a_ms, b_ms, len(df_src))
            # Ensure ts_utc present and normalized
            if "ts_utc" not in df_src.columns:
                # attempt to infer ts_utc from index or other columns
                logger.warning("Provider candles missing ts_utc; cannot synthesize ticks reliably, skipping")
                return {"provider_rows": len(df_src), "inserted": 0, "failed": len(df_src)}
            for idx, r in df_src.iterrows():
                try:
                    ts_val = int(r.get("ts_utc"))
                except Exception:
                    failed += 1
                    continue
                price_val = r.get("close", None)
                payload_tick = {
                    "symbol": symbol,
                    "timeframe": timeframe,
                    "ts_utc": ts_val,
                    "price": price_val,
                    "bid": None,
                    "ask": None,
                    "volume": r.get("volume", None) if "volume" in r else None,
                    "ts_created_ms": int(time.time() * 1000),
                }
                try:
                    ok = dbs.write_tick(payload_tick)
                    if ok:
                        inserted += 1
                    else:
                        failed += 1
                    if sample_logged < sample_log_limit:
                        logger.debug("synth write_tick ts=%s ok=%s price=%s", ts_val, ok, price_val)
                        sample_logged += 1
                except Exception as e:
                    failed += 1
                    logger.exception("synth write_tick exception for ts=%s: {}", ts_val, e)
            logger.info("fetch_and_persist_ticks (synth): provider_rows=%d inserted=%d failed=%d", len(df_src), inserted, failed)
            return {"provider_rows": len(df_src), "inserted": inserted, "failed": failed}

        # Unknown structure: log and skip
        logger.warning("Provider returned data with unexpected columns; skipping persistence for [%s,%s): cols=%s", a_ms, b_m, list(df_src.columns))
        return {"provider_rows": len(df_src), "inserted": 0, "failed": len(df_src)}

    # start main flow
    combined: Dict[str, Any] = {"provider_rows": 0, "ticks_inserted": 0, "candles_upserted": 0, "missing_ranges": []}
    try:
        segments = week_exclusion_segments(int(start_ts_ms), int(end_ts_ms)) or [{"start": int(start_ts_ms), "end": int(end_ts_ms)}]
        for seg in segments:
            a = int(seg["start"]); b = int(seg["end"])
            if b <= a:
                continue
            # determine existing minute buckets
            existing = existing_tick_minutes(engine, a, b)
            # compute missing minute ranges
            miss_ranges = missing_minute_ranges(a, b, existing)
            # collapse/merge small adjacent ranges already returned by helper
            # record missing ranges for report
            for mr in miss_ranges:
                combined["missing_ranges"].append(mr)
            # fetch ticks only for missing ranges
            for mr in miss_ranges:
                a_m = int(mr["start"]); b_m = int(mr["end"])
                rep = fetch_and_persist_ticks_for_range(engine, provider_client, a_m, b_m)
                combined["provider_rows"] += rep.get("provider_rows", 0)
                combined["ticks_inserted"] += rep.get("inserted", 0)

        # After ticks saved, aggregate ticks in the requested window into candles for target timeframe
        try:
            # fetch ticks for full requested window (excluding weekends) and aggregate
            # collect ticks from DB for segments to aggregate
            all_ticks_frames = []
            for seg in segments:
                a = int(seg["start"]); b = int(seg["end"])
                if b <= a:
                    continue
                q = _text("SELECT ts_utc, price, volume FROM market_data_ticks WHERE symbol=:s AND timeframe=:tf AND ts_utc >= :a AND ts_utc < :b ORDER BY ts_utc ASC")
                with engine.connect() as conn:
                    rows = conn.execute(q, {"s": symbol, "tf": timeframe, "a": a, "b": b}).fetchall()
                    if not rows:
                        continue
                    df_ticks = pd.DataFrame([dict(r._mapping) if hasattr(r, "_mapping") else {"ts_utc": r[0], "price": r[1], "volume": r[2] if len(r)>2 else None} for r in rows])
                    all_ticks_frames.append(df_ticks)
            if all_ticks_frames:
                all_ticks = pd.concat(all_ticks_frames, ignore_index=True)
                # aggregate into timeframe rule
                if timeframe.strip().lower().endswith("m"):
                    tf_rule = f"{int(timeframe.strip()[:-1])}min"
                elif timeframe.strip().lower().endswith("h"):
                    tf_rule = f"{int(timeframe.strip()[:-1])}H"
                elif timeframe.strip().lower().endswith("d"):
                    tf_rule = f"{int(timeframe.strip()[:-1])}D"
                else:
                    tf_rule = "1min"
                # prepare datetime index
                all_ticks["ts_dt"] = pd.to_datetime(all_ticks["ts_utc"].astype("int64"), unit="ms", utc=True)
                all_ticks = all_ticks.set_index("ts_dt").sort_index()
                ohlc = all_ticks["price"].resample(tf_rule).ohlc()
                vol = all_ticks["volume"].resample(tf_rule).sum() if "volume" in all_ticks.columns else None
                candles_rows = []
                for idx, row in ohlc.iterrows():
                    if row.isnull().all():
                        continue
                    ts_ms = int(idx.tz_convert("UTC").timestamp() * 1000)
                    o = float(row["open"]) if not pd.isna(row["open"]) else 0.0
                    h = float(row["high"]) if not pd.isna(row["high"]) else o
                    l = float(row["low"]) if not pd.isna(row["low"]) else o
                    c = float(row["close"]) if not pd.isna(row["close"]) else o
                    v = float(vol.loc[idx]) if (vol is not None and idx in vol.index and not pd.isna(vol.loc[idx])) else None
                    candles_rows.append({"ts_utc": ts_ms, "open": o, "high": h, "low": l, "close": c, "volume": v})
                if candles_rows:
                    df_candles = pd.DataFrame(candles_rows)
                    dfv, vreport = validate_candles_df(df_candles, symbol=symbol, timeframe=timeframe)
                    rep = upsert_candles(engine, dfv, symbol, timeframe, resampled=resampled)
                    combined["candles_upserted"] = len(dfv)
                    combined["upsert"] = rep
        except Exception as e:
            logger.exception("Aggregation/upsert of ticks->candles failed: {}", e)
            combined["aggregate_error"] = str(e)

        logger.info("Backfill tick-first completed: %s", combined)

        # Final diagnostic: count raw ticks persisted for this symbol/timeframe
        try:
            with engine.connect() as conn:
                r = conn.execute(text("SELECT COUNT(1) FROM market_data_ticks WHERE symbol=:s AND timeframe=:tf"), {"s": symbol, "tf": timeframe}).scalar() or 0
                logger.info("Final market_data_ticks rows for %s %s: %d", symbol, timeframe, int(r))
        except Exception as e:
            logger.exception("Final tick count query failed: {}", e)

        return combined
    except Exception as e:
        logger.exception("Backfill tick-first failed overall: {}", e)
        raise
